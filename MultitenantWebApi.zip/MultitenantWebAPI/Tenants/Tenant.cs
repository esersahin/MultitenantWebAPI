﻿namespace MultitenantWebAPI.Tenants
{
    public class Tenant {
        public string Id { get; set; }
        public string ConnectionString { get; set; }

    }
}
