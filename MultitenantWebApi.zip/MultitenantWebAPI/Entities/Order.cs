﻿namespace MultitenantWebAPI.Entities
{
    public class Order
    {
        public string TenantId { get; set; }
    }
}
